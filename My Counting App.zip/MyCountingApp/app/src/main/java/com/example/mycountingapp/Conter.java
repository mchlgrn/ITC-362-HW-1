package com.example.mycountingapp;

class Counter {
    public static Integer increaseCount(Integer countInt) {
        return countInt + 1;
    }
}
